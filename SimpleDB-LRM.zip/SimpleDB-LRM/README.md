# SimpleDB-LRM
Simple DB - Implementing efficient buffer management
